# 🚗 Elite Car Detailing - Página Web Premium

Una página web moderna tipo Apple/Tesla dedicada a servicios de Car Detailing, con animaciones avanzadas controladas por scroll usando GSAP + ScrollTrigger.

## ✨ Características

- **Diseño Premium**: Estética moderna tipo Apple/Tesla con glassmorphism y blur
- **Animaciones Avanzadas**: Animaciones basadas en scroll usando GSAP + ScrollTrigger
- **Totalmente Responsive**: Diseño adaptativo para todos los dispositivos
- **Efectos Visuales**: Parallax, zoom, rotación, fade in, slide up, scroll horizontal
- **Secciones Incluidas**:
  - Hero con video background
  - Servicios con tarjetas animadas
  - Proceso paso a paso (Lavado → Descontaminación → Pulido → Coating)
  - Scroll horizontal controlado
  - Slider Antes/Después
  - Precios/Paquetes
  - Formulario de contacto animado
  - Footer moderno

## 🚀 Instalación y Uso

### Opción 1: Usar CDN (Recomendado - Ya incluido)

Los archivos HTML ya incluyen los CDNs de GSAP, así que puedes usar directamente:

1. Descarga todos los archivos del proyecto
2. Abre `index.html` en tu navegador
3. ¡Listo! Las animaciones funcionarán automáticamente

### Opción 2: Instalación Local con Node.js

Si prefieres usar npm (opcional):

```bash
# Instalar GSAP via npm
npm install gsap

# O con yarn
yarn add gsap
```

Luego, actualiza el HTML para usar los archivos locales en lugar de los CDNs.

## 📁 Estructura del Proyecto

```
elite-car-detailing/
│
├── index.html          # Estructura HTML principal
├── styles.css          # Estilos premium con glassmorphism
├── script.js           # Animaciones GSAP + ScrollTrigger
└── README.md           # Este archivo
```

## 🎨 Tecnologías Utilizadas

- **HTML5**: Estructura semántica moderna
- **CSS3**: Glassmorphism, blur, animaciones CSS
- **JavaScript (ES6+)**: Lógica y eventos
- **GSAP 3.12.2**: Animaciones avanzadas
- **ScrollTrigger**: Animaciones basadas en scroll

## 🎬 Animaciones Implementadas

### Hero Section
- Fade + slide al cargar
- Parallax en el video background
- Botón con microinteracción

### Secciones
- **Fade In**: Aparecen suavemente al hacer scroll
- **Slide Up**: Deslizan desde abajo
- **Parallax**: Movimiento de fondo independiente
- **Zoom**: Efecto de acercamiento
- **Rotación**: Rotaciones suaves en elementos
- **Scroll Horizontal**: Sección completa de scroll horizontal

### Servicios
- Cada tarjeta se anima individualmente
- Hover con escalado y rotación
- Efectos glassmorphism

### Proceso
- Pasos animados secuencialmente
- Números con rotación y escala
- Slide desde la izquierda

### Slider Antes/Después
- Transiciones suaves entre slides
- Controles animados
- Dots indicadores

### Formulario
- Animación al enfocar campos
- Labels flotantes
- Botón con efecto hover

## 🔧 Personalización

### Colores
Edita las variables CSS en `styles.css`:

```css
:root {
    --accent-color: #007aff;  /* Color principal */
    --text-primary: #1d1d1f;  /* Texto principal */
    /* ... más variables */
}
```

### Animaciones
Modifica las duraciones y easings en `script.js`:

```javascript
gsap.from(element, {
    duration: 0.8,        // Duración
    ease: 'power3.out',   // Easing
    delay: 0.2            // Retraso
});
```

### Contenido
Edita `index.html` para cambiar textos, imágenes y secciones.

## 📱 Responsive

El diseño se adapta automáticamente a:
- 📱 Móviles (< 768px)
- 📱 Tablets (768px - 1024px)
- 💻 Desktop (> 1024px)

## 🌐 Navegadores Compatibles

- ✅ Chrome (últimas 2 versiones)
- ✅ Firefox (últimas 2 versiones)
- ✅ Safari (últimas 2 versiones)
- ✅ Edge (últimas 2 versiones)

## 📝 Notas

- Las imágenes usan URLs de Unsplash/Mixkit para demostración
- Reemplaza con tus propias imágenes/videos para producción
- El video del hero puede no cargar si la conexión es lenta
- Ajusta las rutas de imágenes según tu estructura de carpetas

## 🎯 Próximos Pasos

1. Reemplaza las imágenes con tus propias fotos
2. Actualiza el video del hero con uno propio
3. Añade un backend para el formulario de contacto
4. Integra Google Analytics
5. Optimiza las imágenes (WebP, lazy loading)
6. Añade más contenido y secciones si es necesario

## 📄 Licencia

Este proyecto es de código abierto y está disponible para uso personal y comercial.

## 🤝 Soporte

Para cualquier pregunta o sugerencia, no dudes en contactarnos.

---

**Desarrollado con ❤️ usando GSAP y ScrollTrigger**

