// ========================================
// GSAP ANIMATIONS CONFIGURATION
// ========================================

// Registrar el plugin ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

// ========================================
// NAVBAR SCROLL EFFECT
// ========================================
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// ========================================
// MOBILE MENU TOGGLE
// ========================================
const menuToggle = document.querySelector('.menu-toggle');
const navMenu = document.querySelector('.nav-menu');

menuToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    menuToggle.classList.toggle('active');
});

// Cerrar menú al hacer clic en un enlace
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        menuToggle.classList.remove('active');
    });
});

// ========================================
// HERO SECTION ANIMATIONS
// ========================================
const heroTimeline = gsap.timeline();

// Animar elementos del hero
heroTimeline
    .from('.hero-title .title-line', {
        y: 100,
        opacity: 0,
        duration: 1,
        stagger: 0.2,
        ease: 'power3.out'
    })
    .from('.hero-subtitle', {
        y: 50,
        opacity: 0,
        duration: 0.8,
        ease: 'power2.out'
    }, '-=0.5')
    .from('.cta-button', {
        y: 30,
        opacity: 0,
        duration: 0.8,
        ease: 'back.out(1.7)'
    }, '-=0.4')
    .from('.scroll-indicator', {
        opacity: 0,
        y: 20,
        duration: 0.8
    }, '-=0.5');

// Parallax para el video del hero
gsap.to('.hero-video', {
    scrollTrigger: {
        trigger: '.hero',
        start: 'top top',
        end: 'bottom top',
        scrub: true
    },
    scale: 1.2,
    y: 100
});

// ========================================
// SERVICES CARDS ANIMATIONS
// ========================================
const serviceCards = document.querySelectorAll('.service-card');

serviceCards.forEach((card, index) => {
    gsap.from(card, {
        scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
        },
        y: 100,
        opacity: 0,
        duration: 0.8,
        delay: index * 0.1,
        ease: 'power3.out',
        rotation: -5
    });

    // Animación de hover con GSAP
    card.addEventListener('mouseenter', () => {
        gsap.to(card, {
            scale: 1.05,
            rotation: 0,
            duration: 0.3,
            ease: 'power2.out'
    });
    });

    card.addEventListener('mouseleave', () => {
        gsap.to(card, {
            scale: 1,
            duration: 0.3,
            ease: 'power2.out'
        });
    });
});

// ========================================
// PROCESS STEPS ANIMATIONS
// ========================================
const processSteps = document.querySelectorAll('.step-item');

processSteps.forEach((step, index) => {
    gsap.from(step, {
        scrollTrigger: {
            trigger: step,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
        },
        x: -200,
        opacity: 0,
        duration: 1,
        delay: index * 0.2,
        ease: 'power3.out',
        rotation: -10
    });

    // Animación de número
    const stepNumber = step.querySelector('.step-number');
    gsap.from(stepNumber, {
        scrollTrigger: {
            trigger: step,
            start: 'top 80%'
        },
        scale: 0,
        rotation: 360,
        duration: 0.8,
        delay: index * 0.2,
        ease: 'back.out(1.7)'
    });
});

// ========================================
// HORIZONTAL SCROLL ANIMATION
// ========================================
const horizontalScroll = document.querySelector('.scroll-content');
const scrollItems = document.querySelectorAll('.scroll-item');

if (horizontalScroll && scrollItems.length > 0) {
    // Calcular el ancho total
    function calculateTotalWidth() {
        let total = 0;
        scrollItems.forEach(item => {
            total += item.offsetWidth;
        });
        return total;
    }

    let totalWidth = calculateTotalWidth();

    // Actualizar totalWidth en resize
    window.addEventListener('resize', () => {
        totalWidth = calculateTotalWidth();
        ScrollTrigger.refresh();
    });

    // Animar el desplazamiento horizontal con ScrollTrigger
    ScrollTrigger.create({
        trigger: '.horizontal-scroll',
        start: 'top top',
        end: () => `+=${totalWidth - window.innerWidth}`,
        pin: true,
        scrub: 1,
        invalidateOnRefresh: true,
        onUpdate: (self) => {
            const progress = self.progress;
            const maxX = -(totalWidth - window.innerWidth);
            gsap.set(horizontalScroll, {
                x: progress * maxX
            });
        }
    });

    // Animar cada item al entrar en vista
    scrollItems.forEach((item, index) => {
        ScrollTrigger.create({
            trigger: item,
            start: 'left 80%',
            end: 'left 20%',
            onEnter: () => {
                gsap.from(item.querySelector('h2'), {
                    y: 100,
                    opacity: 0,
                    duration: 1,
                    ease: 'power3.out'
                });
                gsap.from(item.querySelector('p'), {
                    x: -100,
                    opacity: 0,
                    duration: 1,
                    delay: 0.3,
                    ease: 'power3.out'
                });
            }
        });
    });
}

// ========================================
// BEFORE/AFTER SLIDER
// ========================================
const sliderSlides = document.querySelectorAll('.slider-slide');
const prevBtn = document.querySelector('.slider-btn.prev');
const nextBtn = document.querySelector('.slider-btn.next');
const sliderTrack = document.querySelector('.slider-track');
let currentSlide = 0;

// Crear dots
const dotsContainer = document.querySelector('.slider-dots');
sliderSlides.forEach((_, index) => {
    const dot = document.createElement('div');
    dot.className = 'slider-dot';
    if (index === 0) dot.classList.add('active');
    dot.addEventListener('click', () => goToSlide(index));
    dotsContainer.appendChild(dot);
});

const dots = document.querySelectorAll('.slider-dot');

function goToSlide(index) {
    currentSlide = index;
    updateSlider();
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % sliderSlides.length;
    updateSlider();
}

function prevSlide() {
    currentSlide = (currentSlide - 1 + sliderSlides.length) % sliderSlides.length;
    updateSlider();
}

function updateSlider() {
    // Animar transición
    gsap.to(sliderTrack, {
        x: -currentSlide * 100 + '%',
        duration: 0.8,
        ease: 'power3.inOut'
    });

    // Actualizar clases activas
    sliderSlides.forEach((slide, index) => {
        if (index === currentSlide) {
            slide.classList.add('active');
            gsap.from(slide, {
                scale: 0.9,
                opacity: 0,
                duration: 0.8
            });
        } else {
            slide.classList.remove('active');
        }
    });

    // Actualizar dots
    dots.forEach((dot, index) => {
        if (index === currentSlide) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
}

nextBtn.addEventListener('click', nextSlide);
prevBtn.addEventListener('click', prevSlide);

// Auto-play slider (opcional)
// setInterval(nextSlide, 5000);

// ========================================
// PRICING CARDS ANIMATIONS
// ========================================
const pricingCards = document.querySelectorAll('.pricing-card');

pricingCards.forEach((card, index) => {
    gsap.from(card, {
        scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
        },
        y: 80,
        opacity: 0,
        duration: 0.8,
        delay: index * 0.15,
        ease: 'power3.out',
        scale: 0.9
    });

    // Animación de hover
    card.addEventListener('mouseenter', () => {
        gsap.to(card, {
            y: -10,
            duration: 0.3,
            ease: 'power2.out'
        });
    });

    card.addEventListener('mouseleave', () => {
        gsap.to(card, {
            y: 0,
            duration: 0.3,
            ease: 'power2.out'
        });
    });
});

// ========================================
// CONTACT FORM ANIMATIONS
// ========================================
const formGroups = document.querySelectorAll('.form-group');

formGroups.forEach((group, index) => {
    gsap.from(group, {
        scrollTrigger: {
            trigger: group,
            start: 'top 90%',
            toggleActions: 'play none none reverse'
        },
        x: -50,
        opacity: 0,
        duration: 0.6,
        delay: index * 0.1,
        ease: 'power2.out'
    });
});

// Animación al enfocar inputs
const inputs = document.querySelectorAll('.form-group input, .form-group textarea');

inputs.forEach(input => {
    input.addEventListener('focus', () => {
        gsap.to(input, {
            scale: 1.02,
            duration: 0.3,
            ease: 'power2.out'
        });
    });

    input.addEventListener('blur', () => {
        gsap.to(input, {
            scale: 1,
            duration: 0.3,
            ease: 'power2.out'
        });
    });
});

// Animación del botón submit
gsap.from('.submit-btn', {
    scrollTrigger: {
        trigger: '.contact-form',
        start: 'top 80%'
    },
    y: 30,
    opacity: 0,
    duration: 0.8,
    ease: 'back.out(1.7)'
});

// ========================================
// CONTACT INFO ANIMATIONS
// ========================================
const infoItems = document.querySelectorAll('.info-item');

infoItems.forEach((item, index) => {
    gsap.from(item, {
        scrollTrigger: {
            trigger: item,
            start: 'top 90%',
            toggleActions: 'play none none reverse'
        },
        x: 50,
        opacity: 0,
        duration: 0.6,
        delay: index * 0.1,
        ease: 'power2.out'
    });
});

// ========================================
// FOOTER ANIMATIONS
// ========================================
const footerCols = document.querySelectorAll('.footer-col');

footerCols.forEach((col, index) => {
    gsap.from(col, {
        scrollTrigger: {
            trigger: '.footer',
            start: 'top 80%',
            toggleActions: 'play none none reverse'
        },
        y: 50,
        opacity: 0,
        duration: 0.8,
        delay: index * 0.1,
        ease: 'power3.out'
    });
});

// Animación de links sociales
const socialLinks = document.querySelectorAll('.social-links a');

socialLinks.forEach((link, index) => {
    gsap.from(link, {
        scrollTrigger: {
            trigger: '.social-links',
            start: 'top 90%'
        },
        scale: 0,
        rotation: 180,
        duration: 0.5,
        delay: index * 0.1,
        ease: 'back.out(1.7)'
    });

    // Hover animation
    link.addEventListener('mouseenter', () => {
        gsap.to(link, {
            rotation: 360,
            scale: 1.1,
            duration: 0.3,
            ease: 'power2.out'
        });
    });

    link.addEventListener('mouseleave', () => {
        gsap.to(link, {
            rotation: 0,
            scale: 1,
            duration: 0.3,
            ease: 'power2.out'
        });
    });
});

// ========================================
// SECTION HEADERS ANIMATIONS
// ========================================
const sectionHeaders = document.querySelectorAll('.section-header');

sectionHeaders.forEach(header => {
    gsap.from(header.querySelector('.section-title'), {
        scrollTrigger: {
            trigger: header,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
        },
        y: 50,
        opacity: 0,
        duration: 0.8,
        ease: 'power3.out'
    });

    gsap.from(header.querySelector('.section-subtitle'), {
        scrollTrigger: {
            trigger: header,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
        },
        y: 30,
        opacity: 0,
        duration: 0.8,
        delay: 0.2,
        ease: 'power3.out'
    });
});

// ========================================
// SMOOTH SCROLL ENHANCEMENT
// ========================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            const targetPosition = target.offsetTop - 70;
            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    });
});

// ========================================
// PERFORMANCE OPTIMIZATION
// ========================================
// Lazy load images
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                if (img.dataset.src) {
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                }
                observer.unobserve(img);
            }
        });
    });

    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

// ========================================
// CONSOLE LOG (Para desarrollo)
// ========================================
console.log('✨ Elite Car Detailing - Animaciones GSAP cargadas correctamente');
